package com.redis.moduleapi.entity;

import com.google.gson.annotations.SerializedName;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "movieapi")
public class KMdbApiEntity {
    @Id
    @SerializedName("docid")
    @Column(name = "docid", nullable = false, length = 20)
    private String docid;

    @SerializedName("movieSeq")
    @Column(name = "movieSeq")
    private int movieSeq;

    @SerializedName("title")
    @Column(name = "title", length = 50)
    private String title;

    @SerializedName("titleEng")
    @Column(name = "titleEng", length = 50)
    private String titleEng;

    @SerializedName("titleEtc")
    @Column(name = "titleEtc", length = 50)
    private String titleEtc;

    @SerializedName("directorNm")
    @Column(name = "directorNm", length = 20)
    private String directorNm;

    @SerializedName("directorId")
    @Column(name = "directorId")
    private int directorId;

    @SerializedName("actorNm")
    @Column(name = "actorNm", length = 20)
    private String actorNm;

    @SerializedName("nation")
    @Column(name = "nation", length = 10)
    private String nation;

    @SerializedName("company")
    @Column(name = "company", length = 20)
    private String company;

    @SerializedName("prodYear")
    @Column(name = "prodYear")
    private Instant prodYear;

    @Lob
    @SerializedName("plot")
    @Column(name = "plot")
    private String plot;

    @SerializedName("runtime")
    @Column(name = "runtime")
    private Instant runtime;

    @SerializedName("rating")
    @Column(name = "rating", length = 10)
    private String rating;

    @SerializedName("genre")
    @Column(name = "genre", length = 20)
    private String genre;

    @Lob
    @SerializedName("kmdbUrl")
    @Column(name = "kmdbUrl")
    private String kmdbUrl;

    @SerializedName("type")
    @Column(name = "type", length = 10)
    private String type;

    @SerializedName("use")
    @Column(name = "use", length = 10)
    private String use;

    @Lob
    @SerializedName("episodes")
    @Column(name = "episodes")
    private String episodes;

    @SerializedName("ratedYn")
    @Column(name = "ratedYn")
    private Character ratedYn;

    @SerializedName("repRatDate")
    @Column(name = "repRatDate")
    private Instant repRatDate;

    @SerializedName("repRlsDate")
    @Column(name = "repRlsDate")
    private Instant repRlsDate;

    @SerializedName("ratingGrade")
    @Column(name = "ratingGrade", length = 10)
    private String ratingGrade;

    @SerializedName("releaseDate")
    @Column(name = "releaseDate")
    private Instant releaseDate;

    @SerializedName("keywords")
    @Column(name = "keywords", length = 50)
    private String keywords;

    @Lob
    @SerializedName("posterUrl")
    @Column(name = "posterUrl")
    private String posterUrl;

    @SerializedName("staffRoleGroup")
    @Column(name = "staffRoleGroup", length = 10)
    private String staffRoleGroup;

    @SerializedName("StaffRole")
    @Column(name = "StaffRole", length = 30)
    private String staffRole;

    @Lob
    @SerializedName("StaffEtc")
    @Column(name = "StaffEtc")
    private String staffEtc;

    @SerializedName("openThtr")
    @Column(name = "openThtr", length = 20)
    private String openThtr;

    @SerializedName("screenArea")
    @Column(name = "screenArea", length = 50)
    private String screenArea;

    @SerializedName("screenCnt")
    @Column(name = "screenCnt")
    private int screenCnt;

    @SerializedName("audiAcc")
    @Column(name = "audiAcc")
    private int audiAcc;


}