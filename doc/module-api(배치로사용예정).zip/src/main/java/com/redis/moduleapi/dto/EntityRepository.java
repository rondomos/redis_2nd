package com.redis.moduleapi.dto;

import com.redis.moduleapi.entity.KMdbApiEntity;
import org.springframework.data.repository.CrudRepository;

public interface EntityRepository extends CrudRepository<KMdbApiEntity, String> {
}
