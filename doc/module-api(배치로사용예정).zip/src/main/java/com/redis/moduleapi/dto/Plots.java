
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Plots {

    @SerializedName("plot")
    @Expose
    private List<Plot> plot;

    public List<Plot> getPlot() {
        return plot;
    }

    public void setPlot(List<Plot> plot) {
        this.plot = plot;
    }

}
