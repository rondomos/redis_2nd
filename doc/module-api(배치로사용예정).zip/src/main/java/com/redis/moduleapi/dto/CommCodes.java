
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class CommCodes {

    @SerializedName("CommCode")
    @Expose
    private List<CommCode> commCode;

    public List<CommCode> getCommCode() {
        return commCode;
    }

    public void setCommCode(List<CommCode> commCode) {
        this.commCode = commCode;
    }

}
