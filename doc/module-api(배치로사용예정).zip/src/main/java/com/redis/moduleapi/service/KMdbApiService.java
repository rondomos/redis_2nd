package com.redis.moduleapi.service;

import com.google.gson.*;
import com.redis.moduleapi.dto.*;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;


@Slf4j
@Service
public class KMdbApiService {


    public String getKMdbApi() throws IOException {
        //Logger logger2 = LogManager.getLogger(BoardDao.class); //가능
        String result = "";
        String fullUrl = "http://api.koreafilm.or.kr/openapi-data2/wisenut/search_api/search_json2.jsp?collection=kmdb_new2";
        StringBuilder urlBuilder = new StringBuilder( fullUrl); /*URL*/
        urlBuilder.append("&" + URLEncoder.encode("nation", StandardCharsets.UTF_8)+"="+URLEncoder.encode("%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD", StandardCharsets.UTF_8)); /*nation*/ //한글 대한민국 인코딩한걸 다시 인코딩
        urlBuilder.append("&" + URLEncoder.encode("ServiceKey", StandardCharsets.UTF_8)+"="+"Q5T920A98233R0Z26Y2T"); /*Service Key*/
        urlBuilder.append("&").append(URLEncoder.encode("val001", StandardCharsets.UTF_8)).append("=").append(URLEncoder.encode("2023", StandardCharsets.UTF_8)); /*상영년도*/
        urlBuilder.append("&" + URLEncoder.encode("val002", StandardCharsets.UTF_8) + "=" + URLEncoder.encode("01", StandardCharsets.UTF_8)); /*상영 월*/
        String urlBuilderString = URLDecoder.decode(urlBuilder.toString(), "UTF-8"); //build 할 때 encode 한번 더 해준다고 해서 /부분이 깨짐. 그래서 decode
        URL url = new URL(urlBuilderString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        System.out.println("Response code: " + conn.getResponseCode());
        System.out.println("Response url: " + url);


        BufferedReader rd;
        if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);

        }
        rd.close();
        conn.disconnect();



        try {
            stringToKMdbApiEntity(sb.toString());
            result = "ok";

        }catch (Exception e){
            e.printStackTrace();
            result= "not ok";

        }

        return  result;
    }


    public KMdbApiDto stringToKMdbApiEntity(String sb) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            KMdbApiDto KMdbApidto = gson.fromJson(sb, KMdbApiDto.class);

            // 첫 번째 영화 정보 출력
            if (KMdbApidto.getData() != null && !KMdbApidto.getData().isEmpty()) {
                for (int i = 0; i < KMdbApidto.getData().size(); i++) {
                    Datum datum = KMdbApidto.getData().getFirst();
                    Result result = datum.getResult().getFirst();

                    String title = result.getTitle();
                    String movieId = result.getMovieId();
                    String rating = result.getRating();
                    String docid =    result.getDocid();
                    String titleEtc =    result.getTitleEtc();
                    String statDate =  result.getStatDate();
                    String nation = result.getNation();
                    String genre = result.getGenre();
                    String kmdbUrl = result.getKmdbUrl();
                    String runtime = result.getRuntime();



                    Director director = result.getDirectors().getDirector().get(i);
                    Actor actor = result.getActors().getActor().get(i);
                    Staff staff = result.getStaffs().getStaff().get(i);


                    System.out.println("영화 제목: " + result.getTitle());
                    System.out.println("제작 연도: " + result.getProdYear());
                    System.out.println("감독: " + director.getDirectorNm());
                    System.out.println("주연 배우: " + actor.getActorNm());


                    return KMdbApidto;
                 }

                }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }

        return null;
    }
}

