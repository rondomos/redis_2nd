package com.redis.moduleapi.controller;


import com.redis.moduleapi.service.KMdbApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;


@RestController
public class KMdbApiController {

    @Autowired
    KMdbApiService kmdbApiService;

    @GetMapping("/KMdb")
    public String saveKMdbApi() throws IOException {

        String result = "";

        try {
            result =  kmdbApiService.getKMdbApi();
        }catch (Exception e){
            e.printStackTrace();
        }

        return result;
    }

}


