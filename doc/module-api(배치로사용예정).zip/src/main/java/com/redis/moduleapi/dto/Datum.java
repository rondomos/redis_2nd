
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Datum {

    @SerializedName("CollName")
    @Expose
    private String collName;
    @SerializedName("TotalCount")
    @Expose
    private Integer totalCount;
    @SerializedName("Count")
    @Expose
    private Integer count;
    @SerializedName("Result")
    @Expose
    private List<Result> result;

    public String getCollName() {
        return collName;
    }

    public void setCollName(String collName) {
        this.collName = collName;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<Result> getResult() {
        return result;
    }

    public void setResult(List<Result> result) {
        this.result = result;
    }

}
