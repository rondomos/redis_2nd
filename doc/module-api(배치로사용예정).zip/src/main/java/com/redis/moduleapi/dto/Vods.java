
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Vods {

    @SerializedName("vod")
    @Expose
    private List<Vod> vod;

    public List<Vod> getVod() {
        return vod;
    }

    public void setVod(List<Vod> vod) {
        this.vod = vod;
    }

}
