package com.redis.moduleapi;

import com.redis.moduleapi.controller.KMdbApiController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class ModuleApiApplication {

    public static void main(String[] args) throws IOException {
        SpringApplication.run(ModuleApiApplication.class, args);
    }

}
