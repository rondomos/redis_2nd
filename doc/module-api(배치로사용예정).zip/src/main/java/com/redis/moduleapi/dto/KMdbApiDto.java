
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class KMdbApiDto {

    @SerializedName("Query")
    @Expose
    private String query;
    @SerializedName("KMAQuery")
    @Expose
    private String kMAQuery;
    @SerializedName("TotalCount")
    @Expose
    private Integer totalCount;
    @SerializedName("Data")
    @Expose
    private List<Datum> data;

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getKMAQuery() {
        return kMAQuery;
    }

    public void setKMAQuery(String kMAQuery) {
        this.kMAQuery = kMAQuery;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "KMdbApiDto{" +
                "query='" + query + '\'' +
                ", kMAQuery='" + kMAQuery + '\'' +
                ", totalCount=" + totalCount +
                ", data=" + data +
                '}';
    }
}
