
package com.redis.moduleapi.dto;

import java.util.List;
import jakarta.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Codes {

    @SerializedName("Code")
    @Expose
    private List<Code> code;

    public List<Code> getCode() {
        return code;
    }

    public void setCode(List<Code> code) {
        this.code = code;
    }

}
